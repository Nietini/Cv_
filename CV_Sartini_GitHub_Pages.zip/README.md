# CV Online Sartini

Website CV statis untuk dipublikasikan dengan GitHub Pages.

Setelah file `index.html` diunggah ke repository GitHub, buka **Settings → Pages**, pilih **Deploy from a branch**, branch **main**, folder **/(root)**, lalu Save.
